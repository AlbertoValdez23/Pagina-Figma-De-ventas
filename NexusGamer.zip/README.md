
  # NexusGamer

  This is a code bundle for NexusGamer. The original project is available at https://www.figma.com/design/2jJXldGNAqZl1SRtxl7BtY/NexusGamer.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  