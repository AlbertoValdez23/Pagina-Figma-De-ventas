import { Button } from './ui/button';
import { Input } from './ui/input';
import { Separator } from './ui/separator';
import { Cpu, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white border-t border-blue-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-gradient-to-br from-blue-500 to-violet-600 rounded-lg">
                <Cpu className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-violet-400 bg-clip-text text-transparent">
                NexusGamer CR
              </span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed">
              Tu tienda gamer de confianza en Nuevo Laredo.
              Hardware premium, periféricos y accesorios al mejor precio en pesos.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="sm" className="hover:text-blue-400 text-slate-400 hover:bg-blue-900/30">
                <Facebook className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm" className="hover:text-blue-400 text-slate-400 hover:bg-blue-900/30">
                <Twitter className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm" className="hover:text-blue-400 text-slate-400 hover:bg-blue-900/30">
                <Instagram className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm" className="hover:text-blue-400 text-slate-400 hover:bg-blue-900/30">
                <Youtube className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Links */}
          <div className="space-y-4">
            <h3 className="font-semibold text-white">Catálogo</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">
                  Computadoras Gamer
                </a>
              </li>
              <li>
                <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">
                  Laptops Gaming
                </a>
              </li>
              <li>
                <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">
                  Monitores
                </a>
              </li>
              <li>
                <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">
                  Periféricos
                </a>
              </li>
              <li>
                <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">
                  Audífonos y Headsets
                </a>
              </li>
            </ul>
          </div>

          {/* Customer Service */}
          <div className="space-y-4">
            <h3 className="font-semibold text-white">Atención al Cliente</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">
                  Política de Garantía
                </a>
              </li>
              <li>
                <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">
                  Envíos y Entregas
                </a>
              </li>
              <li>
                <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">
                  Términos y Condiciones
                </a>
              </li>
              <li>
                <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">
                  Política de Privacidad
                </a>
              </li>
              <li>
                <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">
                  Soporte Técnico
                </a>
              </li>
            </ul>
          </div>

          {/* Contact & Newsletter */}
          <div className="space-y-4">
            <h3 className="font-semibold text-white">Contacto</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-2 text-slate-400">
                <MapPin className="h-4 w-4 text-blue-400" />
                <span>San jacinto Villas, Nuevo Laredo</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-400">
                <Phone className="h-4 w-4 text-blue-400" />
                <span>+506 2200-GAMER</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-400">
                <Mail className="h-4 w-4 text-blue-400" />
                <span>info@nexusgamer.cr</span>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium text-sm text-white">Newsletter Gamer</h4>
              <p className="text-xs text-slate-400">
                Recibe ofertas exclusivas y lanzamientos de hardware
              </p>
              <div className="flex space-x-2">
                <Input
                  type="email"
                  placeholder="Tu email"
                  className="bg-slate-800 border-slate-700 text-white placeholder-slate-500 focus:border-blue-500"
                />
                <Button className="bg-gradient-to-r from-blue-500 to-violet-600 hover:from-blue-600 hover:to-violet-700 border-0 text-white">
                  Unirse
                </Button>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-8 bg-slate-800" />

        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-sm text-slate-500">
            © 2025 NexusGamer CR. Todos los derechos reservados.
          </div>
          <div className="flex space-x-6 text-sm text-slate-500">
            <a href="#" className="hover:text-blue-400 transition-colors">
              Garantía Oficial
            </a>
            <a href="#" className="hover:text-blue-400 transition-colors">
              Envío Express
            </a>
            <a href="#" className="hover:text-blue-400 transition-colors">
              Soporte 24/7
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
